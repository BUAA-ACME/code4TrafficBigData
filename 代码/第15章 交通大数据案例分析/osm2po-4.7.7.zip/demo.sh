#! /bin/sh

java -Xmx512m -jar osm2po-core-4.7.7-signed.jar prefix=hh tileSize=x http://download.geofabrik.de/europe/germany/hamburg-latest.osm.pbf

